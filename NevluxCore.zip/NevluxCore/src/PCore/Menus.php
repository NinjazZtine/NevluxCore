<?php

namespace PCore;

use pocketmine\Player;
use pocketmine\utils\Config;

use PCore\Core;
use PCore\API\SimpleForm;
use PCore\API\CustomForm;
use PCore\Duels\Duels;
use PCore\ScoreSystem;
use PCore\Misc\TimePlayed;

use PCore\FFA\ {
	Fist,
	Resistance,
	Resistance2,
	Sumo,
	Gapple,
	Nodebuff,
	Combo,
	Soup,
	Build,
	Knockback
};


class Menus {

	public function FFAMenu($player) {
		$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
			switch ($data) {
				case "fist":
					$game = new Fist();
					$game->Fist($player);
					break;
				case "resistance":
					$game = new Resistance();
					$game->Resistance($player);
					break;
				case "resistance2":
					$game = new Resistance2();
					$game->Resistance2($player);
					break;
				case "sumo":
					$game = new Sumo();
					$game->Sumo($player);
					break;
				case "gapple":
					$game = new Gapple();
					$game->Gapple($player);
					break;
				case "nodebuff":
					$game = new Nodebuff();
					$game->Nodebuff($player);
					break;
				case "combo":
					$game = new Combo();
					$game->Combo($player);
					break;
				case "soup":
					$game = new Soup();
					$game->Soup($player);
					break;
				case "build":
					$game = new Build();
					$game->Build($player);
					break;
				case "knockback":
					$game = new Knockback();
					$game->Knockback($player);
					break;
				case "offline":
					$player->sendMessage("§4This Arena is Currently Oflline");
					break;
			}
		});
		$config = Core::getInstance()->config;
		$fistWorld = $config->get("FFAWorlds")["Fist"];
		$resistanceWorld = $config->get("FFAWorlds")["Resistance"];
		$resistance2World = $config->get("FFAWorlds")["Resistance2"];
		$sumoWorld = $config->get("FFAWorlds")["Sumo"];
		$gappleWorld = $config->get("FFAWorlds")["Gapple"];
		$nodebuffWorld = $config->get("FFAWorlds")["Nodebuff"];
		$comboWorld = $config->get("FFAWorlds")["Combo"];
		$soupWorld = $config->get("FFAWorlds")["Soup"];
		$buildWorld = $config->get("FFAWorlds")["Build"];
		$knockbackWorld = $config->get("FFAWorlds")["Knockback"];

		$server = Core::getInstance()->getServer();
		$fist = $server->getLevelByName($fistWorld);
		$resistance = $server->getLevelByName($resistanceWorld);
		$resistance2 = $server->getLevelByName($resistance2World);
		$sumo = $server->getLevelByName($sumoWorld);
		$gapple = $server->getLevelByName($gappleWorld);
		$nodebuff = $server->getLevelByName($nodebuffWorld);
		$combo = $server->getLevelByName($comboWorld);
		$soup = $server->getLevelByName($soupWorld);
		$build = $server->getLevelByName($buildWorld);
		$knockback = $server->getLevelByName($knockbackWorld);

		if (!$server->isLevelLoaded($fistWorld)) {
			$pfist = "§4Offline";
			$c0 = "offline";
		} else {
			$pfist = "Playing: " . count($fist->getPlayers());
			$c0 = "fist";
		}
		if (!$server->isLevelLoaded($resistanceWorld)) {
			$presistance = "§4Offline";
			$c1 = "offline";
		} else {
			$presistance = "Playing: " . count($resistance->getPlayers());
			$c1 = "resistance";
		}
		if (!$server->isLevelLoaded($resistance2World)) {
			$presistance2 = "§4Offline";
			$c2 = "offline";
		} else {
			$presistance2 = "Playing: " . count($resistance2->getPlayers());
			$c2 = "resistance2";
		}
		if (!$server->isLevelLoaded($sumoWorld)) {
			$psumo = "§4Offline";
			$c3 = "offline";
		} else {
			$psumo = "Playing: " . count($sumo->getPlayers());
			$c3 = "sumo";
		}
		if (!$server->isLevelLoaded($gappleWorld)) {
			$pgapple = "§4Offline";
			$c4 = "offline";
		} else {
			$pgapple = "Playing: " . count($gapple->getPlayers());
			$c4 = "gapple";
		}
		if (!$server->isLevelLoaded($nodebuffWorld)) {
			$pnodebuff = "§4Offline";
			$c5 = "offline";
		} else {
			$pnodebuff = "Playing: " . count($nodebuff->getPlayers());
			$c5 = "nodebuff";
		}
		if (!$server->isLevelLoaded($comboWorld)) {
			$pcombo = "§4Offline";
			$c6 = "offline";
		} else {
			$pcombo = "Playing: " . count($combo->getPlayers());
			$c6 = "combo";
		}
		if (!$server->isLevelLoaded($soupWorld)) {
			$psoup = "§4Offline";
			$c7 = "offline";
		} else {
			$psoup = "Playing: " . count($soup->getPlayers());
			$c7 = "soup";
		}
		if (!$server->isLevelLoaded($buildWorld)) {
			$pbuild = "§4Offline";
			$c8 = "offline";
		} else {
			$pbuild = "Playing: " . count($build->getPlayers());
			$c8 = "build";
		}
		if (!$server->isLevelLoaded($knockbackWorld)) {
			$pknockback = "§4Offline";
			$c9 = "offline";
		} else {
			$pknockback = "Playing: " . count($knockback->getPlayers());
			$c9 = "knockback";
		}
		$menu->setTitle("§l§0»§aFree For All§0«");
		$menu->addButton("§0Build\n§r§7 $pbuild", 0, "textures/items/iron_pickaxe", $c8);
		$menu->addButton("§0Fist\n§r§7 $pfist", 0, "textures/items/beef_cooked", $c0);
		$menu->addButton("§0Resistance\n§r§7 $presistance", 0, "textures/ui/resistance_effect", $c1);
		$menu->addButton("§0Resistance 2\n§r§7 $presistance2", 0, "textures/ui/resistance_effect", $c2);
		$menu->addButton("§0Sumo\n§r§7 $psumo", 0, "textures/items/feather", $c3);
		$menu->addButton("§0Gapple\n§r§7 $pgapple", 0, "textures/items/apple_golden", $c4);
		$menu->addButton("§0Nodebuff\n§r§7 $pnodebuff", 0, "textures/items/potion_bottle_splash_heal", $c5);
		$menu->addButton("§0Combo\n§r§7 $pcombo", 0, "textures/items/fish_pufferfish_raw", $c6);
		$menu->addButton("§0Soup\n§r§7 $psoup", 0, "textures/items/mushroom_stew", $c7);
		$menu->addButton("§0Knockback\n§r§7 $pknockback", 0, "textures/items/stick", $c9);
		$menu->sendToPlayer($player);
	}


	public function HubMenu($player) {
		$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
			switch ($data) {
				case "settings":
					$this->SettingsTab($player);
					break;
				case "stats":
					$this->PlayerStats($player);
					break;
			}
		});
		$menu->setTitle("§l§0»§2Menu§0«");
		$menu->addButton("§2Settings", 0, "", "settings");
		$menu->addButton("§2Stats", 0, "", "stats");
		$menu->sendToPlayer($player);
	}

	public function SettingsTab($player) {
		$menu = new CustomForm(function(Player $player, array $data = null) {
			if ($data === null) return true;
			$setting = new Config(Core::getInstance()->getDataFolder() . "data/players/" . $player->getLowerCaseName() . ".yml", Config::YAML);

			$setting->setNested("Settings.arena_spawn", $data["arenaSpawn"]);
			$setting->setNested("Settings.cps_popup", $data["cps_display"]);
			$setting->setNested("Settings.distance_popup", $data["distance_display"]);
			$setting->setNested("Settings.combo_popup", $data["combo_display"]);

			$setting->save();
		});
		$setting = new Config(Core::getInstance()->getDataFolder() . "data/players/" . $player->getLowerCaseName() . ".yml",
			Config::YAML);
		$menu->setTitle("§l§0»§2Settings§0«");
		
		$menu->addToggle("§aArenaSpawn",
			$setting->get("Settings")["arena_spawn"],
			"arenaSpawn");
		$menu->addToggle("§aCps Display",
			$setting->get("Settings")["cps_popup"],
			"cps_display");
		$menu->addToggle("§aReach/Distance Display",
			$setting->get("Settings")["distance_popup"],
			"distance_display");
		$menu->addToggle("§aCombo Display",
			$setting->get("Settings")["combo_popup"],
			"combo_display");
		$menu->addToggle("§aScoreHud",
			true,
			"scorehud");
		$menu->sendToPlayer($player);
	}

	
	public function PlayerStats($player) {
				$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
		});
		$score = new ScoreSystem();
		
		$menu->setTitle("§l§0»§1§l" . $player->getName() . "'s§r§1 Stats§0«");
		$menu->setContent(
			"§lIgn: " . $player->getName() . "§r\n" .
			"Total Time Played: " . TimePlayed::getPlayTime($player) . "\n\n" .
			
			"Elo: " . $score->getElo($player) . "\n" .
			"Kills: " . $score->getKP($player) . "\n" . 
			"Deaths: " . $score->getDP($player) . "\n" . 
			"KDR: " . $score->getKDR($player) . "\n");
			
		$menu->sendToPlayer($player);
	}


	public function ChangelogsTab($player) {
		$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
		});
		$logs = Core::getInstance()->config->get("Changelogs");
		$menu->setTitle("§l§cChangelogs");
		$menu->setContent($logs);
		$menu->sendToPlayer($player);
	}


	public function DiscordTab($player) {
		$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
		});
		$menu->setTitle("§l§2Discord");
		$menu->setContent("§adiscord.gg/example");
		$menu->sendToPlayer($player);
	}
	
	public function DuelsMenu(Player $player) {
		$menu = new SimpleForm(function(Player $player, $data = null) {
			if ($data === null) return true;
			switch($data) {
				case "Ranked":
					$this->DuelsRanked($player);
					break;
				case "Unranked":
					$this->DuelsUnRanked($player);
					break;
			}
		});
		$menu->setTitle("§l§0»§aDuels§0«");
		$menu->addButton("§0Ranked", 0, "textures/items/diamond_sword", "Ranked");
		$menu->addButton("§0Unranked", 0, "textures/items/iron_sword", "Unranked");
		$menu->addButton("§0Spectate §4(Comming SSoon§r", 0, "textures/items/ender_eye", "Spectate");
		$menu->sendToPlayer($player);
	}

	public function DuelsRanked(Player $player) {
		$menu = new SimpleForm(function (Player $player, $data = null) {
			if ($data === null) return true;
			$duels = new Duels();
			$arena = Duels::getArenas()[$data];
			$duels->joinToArena($player, $arena);
		});
		$duels = new Duels();
		$menu->setTitle("§l§0»§aRanked Duels§0«");
		$menu->setContent("");
		foreach (Duels::getArenas() as $arena) {
			if ($duels->isRanked($arena)) {
				$inQueue = count($duels->getPlayers($arena));
				$menu->addButton("§0$arena \n In-queue: $inQueue ");
			}
		}
		$menu->sendToPlayer($player);
	}
	
	public function DuelsUnRanked(Player $player) {
		$menu = new SimpleForm(function (Player $player, $data = null) {
			if ($data === null) return true;
			$duels = new Duels();
			$arena = Duels::getArenas()[$data];
			$duels->joinToArena($player, $arena);
		});
		$duels = new Duels();
		$menu->setTitle("§l§0»§aUnRanked Duels§0«");
		$menu->setContent("");
		foreach (Duels::getArenas() as $arena) {
			if (!$duels->isRanked($arena)) {
				$inQueue = count($duels->getPlayers($arena));
				$menu->addButton("§0$arena \n In-queue: $inQueue ");
			}
		}
		$menu->sendToPlayer($player);
	}
}